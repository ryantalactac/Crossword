//
//  LevelViewController.swift
//  crossword
//
//  Created by ry on 4/17/19.
//  Copyright © 2019 ry. All rights reserved.
//

import UIKit

class LevelViewController: UIViewController {
   
    @IBOutlet var tswiftBtn:UIButton!
    @IBOutlet var generalBtn:UIButton!
    
    var answers:String = "puzzles/COSSWORD.txt"
    var numDown:String = "puzzles/down.txt"
    var numAcross:String = "puzzles/across.txt"
    var qAcross:String = "puzzles/qAcross.txt"
    var qDown:String = "puzzles/qDown.txt"
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func levelSelect(send: UIButton){
        switch send {
        case tswiftBtn:
            answers = "puzzles/tswift.txt"
            numDown = "puzzles/tswiftDown.txt"
            numAcross = "puzzles/tswiftAcross.txt"
            qAcross = "puzzles/tswiftAcrossQ.txt"
            qDown = "puzzles/tswiftDownQ.txt"
            break
        case generalBtn:
            answers = "puzzles/COSSWORD.txt"
            numDown = "puzzles/down.txt"
            numAcross = "puzzles/across.txt"
            qAcross = "puzzles/qAcross.txt"
            qDown = "puzzles/qDown.txt"
            break
        default:
            break
        }
    }

    @IBAction func start(sender: UIButton) {
        performSegue(withIdentifier: "game", sender: self)
        
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let vc = segue.destination as! ViewController
        vc.finalAnswers = self.answers
        vc.finalNumDown = self.numDown
        vc.finalNumAcross = self.numAcross
        vc.finalQAcross = self.qAcross
        vc.finalQDown = self.qDown
    }


}
